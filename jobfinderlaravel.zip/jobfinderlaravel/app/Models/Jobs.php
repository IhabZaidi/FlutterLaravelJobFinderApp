<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Jobs extends Model
{
    use HasFactory;
    protected $fillable = ['job_title', 'job_company', 'job_time', 'job_type', 'job_hourly_rate', 'job_is_rec'];
}
